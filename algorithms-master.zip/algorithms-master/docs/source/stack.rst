.. role:: hidden
    :class: hidden-section

algorithms.stack
=================
